LifeOS Mobile — the same app, running entirely on your phone, offline
=====================================================================
Contents:  app/  (the installable web app)   |   LifeOS-Mobile-single-file.html  (quick-try copy)

This is NOT an APK: no Android build tools were available where this was built. It is an installable
web app (PWA). Once installed it opens like a normal app, works with no internet, and keeps all data
inside your phone. Nothing is sent anywhere.

SET-UP (once, ~2 minutes): installing and working offline requires an https address. Upload the "app" folder to any
free static host (Netlify, Cloudflare Pages, GitHub Pages) to get one. Then on the phone: open the link once while
online -> Android Chrome: menu -> Install app / iPhone Safari: Share -> Add to Home Screen.

QUICK TRY: open LifeOS-Mobile-single-file.html in the phone browser. No install/offline caching; some browsers do not keep
local-file data reliably, so use it for trying only.

KEEP YOUR DATA SAFE: data lives only on the phone. Use Data and Backups -> "Download a backup file now" regularly and keep
the file in Files/Drive/email; "Protect my data" asks the browser not to clear storage. Restore with "Restore from a file...".
A phone backup (.db) is accepted by the Windows version and the JSON export imports into either; there is no automatic sync.

TESTED: identical results to the Windows version on a 117-step scripted scenario (expenses, portfolio, reports, backup,
restore); all pages on a Pixel 7 viewport without horizontal scroll or errors; persistence after reload; offline use;
backup download/restore; Arabic/RTL. NOT TESTED: on a real Android/iPhone device or Safari. iOS may clear site data of apps
not used for a while: install to the Home Screen and keep backup files.
